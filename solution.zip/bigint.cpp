#include <iomanip>
#include <iterator>
#include <sstream>
#include <string>
#include "bigint.h"

BigInt::BigInt() {
  bit_string = {0};
}

BigInt::BigInt(uint64_t val, bool negative) {
  bit_string = {};
  bit_string.push_back(val);
  sign = negative;
}

BigInt::BigInt(std::initializer_list<uint64_t> vals, bool negative) {
  bit_string = {};
  for (auto element :  vals) {
    bit_string.push_back(element);
  }
  sign = negative ? negative : false;
}

BigInt::BigInt(const BigInt &other) {
 for (auto elem : other.get_bit_vector()) {
  bit_string.push_back(elem);
 }
 sign = other.sign;
}

BigInt::~BigInt() {
  
}

BigInt &BigInt::operator=(const BigInt &rhs)
{
  // TODO: implement
}

bool BigInt::is_negative() const {
  return sign;
}

const std::vector<uint64_t> &BigInt::get_bit_vector() const {
  return bit_string;
}

uint64_t BigInt::get_bits(unsigned index) const {
  return index > bit_string.size() - 1 ? 0 : bit_string.at(index);
}

BigInt BigInt::operator+(const BigInt &rhs) const
{
  // TODO: implement
}

BigInt BigInt::operator-(const BigInt &rhs) const
{
  // TODO: implement
  // Hint: a - b could be computed as a + -b
}

BigInt BigInt::operator-() const {
  BigInt output = *this;
  output.sign = !sign;
  return output;
}

bool BigInt::is_bit_set(unsigned n) const
{
  // TODO: implement
}

BigInt BigInt::operator<<(unsigned n) const
{
  // TODO: implement
}

BigInt BigInt::operator*(const BigInt &rhs) const
{
  // TODO: implement
}

BigInt BigInt::operator/(const BigInt &rhs) const
{
  // TODO: implement
}

int BigInt::compare(const BigInt &rhs) const
{
  // TODO: implement
}

std::string BigInt::to_hex() const {
  std::stringstream output;
  bool inserted_sig_bit = false;
  if (sign && !(bit_string.size() == 1 && bit_string[0] == 0)) {
    output << "-";
  }
  output << std::hex;

  std::vector<uint64_t>::const_reverse_iterator it = bit_string.rbegin();

  while (it != bit_string.rend()) {
    if (it == bit_string.rbegin()) {
      if (*it != 0 || bit_string.size() == 1) {
        output << *it;
        inserted_sig_bit = true;
        output << std::setfill('0') << std::setw(16);
      }
    } else if (inserted_sig_bit || *it != 0 || std::distance(it, bit_string.rend()) == 1){
      output << *it;
      inserted_sig_bit = true;
      output << std::setfill('0') << std::setw(16);
    }
    it++;
  }

  std::string test = output.str();
  return test;

}

std::string BigInt::to_dec() const
{
  // TODO: implement
}

